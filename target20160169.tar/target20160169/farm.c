/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_206(unsigned x)
{
    return x + 2428995912U;
}

void setval_468(unsigned *p)
{
    *p = 1170462934U;
}

void setval_177(unsigned *p)
{
    *p = 1480652221U;
}

void setval_271(unsigned *p)
{
    *p = 3277343254U;
}

unsigned addval_352(unsigned x)
{
    return x + 2429000008U;
}

unsigned getval_119()
{
    return 3284633960U;
}

void setval_373(unsigned *p)
{
    *p = 3347662931U;
}

void setval_218(unsigned *p)
{
    *p = 2438507532U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_120()
{
    return 3767077103U;
}

unsigned getval_448()
{
    return 3465110080U;
}

unsigned getval_208()
{
    return 3523789481U;
}

unsigned addval_330(unsigned x)
{
    return x + 3523793289U;
}

unsigned addval_276(unsigned x)
{
    return x + 2425406089U;
}

void setval_196(unsigned *p)
{
    *p = 3380924045U;
}

unsigned addval_129(unsigned x)
{
    return x + 2497743176U;
}

unsigned getval_349()
{
    return 3286272328U;
}

unsigned addval_197(unsigned x)
{
    return x + 3677405833U;
}

void setval_421(unsigned *p)
{
    *p = 3230974601U;
}

void setval_397(unsigned *p)
{
    *p = 3229929857U;
}

unsigned getval_295()
{
    return 3677933185U;
}

unsigned addval_267(unsigned x)
{
    return x + 3531919001U;
}

unsigned getval_473()
{
    return 3232027017U;
}

unsigned addval_236(unsigned x)
{
    return x + 2425671305U;
}

unsigned getval_190()
{
    return 3531133321U;
}

unsigned addval_266(unsigned x)
{
    return x + 3286272264U;
}

unsigned getval_181()
{
    return 3263793414U;
}

void setval_324(unsigned *p)
{
    *p = 3677930185U;
}

void setval_199(unsigned *p)
{
    *p = 3286272344U;
}

void setval_420(unsigned *p)
{
    *p = 2495777057U;
}

unsigned getval_341()
{
    return 3224424073U;
}

unsigned getval_355()
{
    return 3674784395U;
}

unsigned addval_412(unsigned x)
{
    return x + 3531919785U;
}

void setval_353(unsigned *p)
{
    *p = 3372798347U;
}

void setval_302(unsigned *p)
{
    *p = 3285093212U;
}

unsigned addval_223(unsigned x)
{
    return x + 3378565513U;
}

unsigned getval_472()
{
    return 2497743176U;
}

unsigned addval_146(unsigned x)
{
    return x + 3767027836U;
}

void setval_358(unsigned *p)
{
    *p = 3221802633U;
}

unsigned getval_209()
{
    return 3531919753U;
}

unsigned addval_294(unsigned x)
{
    return x + 3286272328U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
